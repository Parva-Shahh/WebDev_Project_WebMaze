# WebDev_Project_WebMaze
Wireframe Prototype:
The team has designed a low fidelity wireframe prototype which will directly influence how the websites homepage looks. The wireframe includes a logo, the website name as the header, navigation buttons alongside a search bar to search for individual vehicles. The navigation sections includes 3 buttons which link to three pages – the homepage, the about page and the contact us page. Details of each page are provided below.

Homepage
The homepage consists of a header, navigation buttons, a car of the week, more cars in the collection section and the footer. At the start of the page, user are greeted with a header which has the title of the webpage along with a logo which our design team has developed for this site. Below that are the navigation buttons to go to the about or contact webpages if the user wishes to do so. Further below will be a special section showing your favourite or newly acquired car under the title of “Car of The Week”. Scrolling a bit further users would find 3 of your most exquisite cars. Lastly the footer includes a quote from your most famous buyer as well as an additional contact us section with basic information.

About page
The about page is completely based you – the owner of O’Reilly Wheels. Users are first greeted with an image of the car that started it all, the first car you fell in love with - Mercedes W115. The page goes on to show your love for the automotive and how you were smitten and fascinated with vehicles. It also showcases your education as well as the purpose for which this website was built – to bring the love that you have for cars to the mass public by helping people find their perfect car. 

Contact Us page
The contact us page are for any inquires that the user may have. We ask the user to enter their name, email, phone number and their query into an on-page form. The results of these are sent directly to you and to our dedicated response team, which will answer these questions as soon as they can to provide a positive user experience. 
